<?php

$db_connect= mysqli_connect('localhost','root','','kufa');

?>
