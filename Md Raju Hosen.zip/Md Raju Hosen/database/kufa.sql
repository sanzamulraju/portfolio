-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 16, 2022 at 10:31 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kufa`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` int NOT NULL,
  `educational_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `archive_year` int NOT NULL,
  `education_prg` int NOT NULL,
  `about_status` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `about_me` text COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `educational_title`, `archive_year`, `education_prg`, `about_status`, `about_me`) VALUES
(6, 'JSC', 1994, 100, 'active', 'Est harum soluta eo'),
(7, 'SSC', 1987, 100, 'active', 'Ea consequatur Solu'),
(8, 'HSC', 1988, 69, 'active', 'Non molestiae est eo'),
(9, 'DIPLOMA IN COMPIUTER', 1977, 91, 'active', 'Aut dolor non sed re'),
(10, 'BACELORE', 1982, 100, 'active', 'Reprehenderit quod n'),
(11, 'elaj bhgf', 2001, 100, 'inactive', 'Omnis vero id alias'),
(12, 'MSC', 2006, 100, 'active', 'Esse mollit archite'),
(13, 'Calvin HSAsdhb', 1988, 100, 'active', 'Quisquam molestiae q');

-- --------------------------------------------------------

--
-- Table structure for table `aouths`
--

CREATE TABLE `aouths` (
  `id` int NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `phone_number` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `profile_pic` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'demo.png',
  `facebook` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `instagram` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `linkedin` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `adress` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `aouths`
--

INSERT INTO `aouths` (`id`, `name`, `email`, `password`, `phone_number`, `profile_pic`, `facebook`, `twitter`, `instagram`, `linkedin`, `adress`) VALUES
(16, 'joluhedec', 'pimebyture@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(30, 'Sanzamul Hasan Raju', 'dubefep@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', '01819808403', '30.jpg', 'https://www.facebook.com/', 'https://twitter.com/', 'https://www.instagram.com/', 'https://www.linkedin.com/', 'Magura Khulna Bangladesh'),
(31, 'zyricapuqo', 'lopejowi@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(32, 'ciqely', 'lusemos@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(34, 'vezyhu', 'gytuk@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(35, 'suredi', 'baqusasy@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(37, 'Herrod Allen', 'gilofoha@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', '+1 (646) 578-9848', '37.jpg', NULL, NULL, NULL, NULL, NULL),
(38, 'sesabopi', 'qiky@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(39, 'sukafitycu', 'vohaj@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(40, 'xitufyk', 'peli@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(41, 'silawuc', 'nufiw@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(43, 'komunal', 'dugohehep@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(45, 'fixuqyj', 'ruwolikado@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(46, 'hiper', 'wegeb@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL),
(47, 'qyteqisyt', 'qubinipoki@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', NULL, 'demo.png', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int NOT NULL,
  `brand_status` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `brand_img` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_status`, `brand_img`) VALUES
(1, 'inactive', '1_1668631627.png'),
(3, 'active', '30_1668630239.png'),
(4, 'active', '30_1668637029.png'),
(5, 'active', '30_1668637041.png'),
(6, 'active', '30_1668637054.png'),
(7, 'active', '30_1668637063.png'),
(9, 'active', '30_1668637089.jpg'),
(10, 'active', '30_1668637098.png'),
(11, 'active', '30_1668637109.png'),
(12, 'active', '30_1668637120.png'),
(13, 'active', '30_1668637129.jpg'),
(14, 'active', '30_1668637138.jpg'),
(15, 'active', '30_1668637148.png'),
(16, 'active', '30_1668637154.jpg'),
(17, 'active', '30_1668637174.jpg'),
(18, 'active', '30_1668637194.png');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `message`) VALUES
(5, 'Idona Moore', 'tyxofoh@mailinator.com', 'Deleniti et Nam solu'),
(6, 'Kim Day', 'cysedyc@mailinator.com', 'Necessitatibus ut du'),
(7, 'Whilemina Miller', 'huki@mailinator.com', 'Deleniti veniam mod'),
(8, 'Ginger Medina', 'wubeqoz@mailinator.com', 'Excepteur in consequ'),
(9, 'Warren Fletcher', 'qazewaw@mailinator.com', 'Ea nulla omnis saepe'),
(10, 'Shay Galloway', 'vipom@mailinator.com', 'Corporis sint unde e'),
(11, 'Hyatt Ramsey', 'dawazak@mailinator.com', 'Est do et vel nisi e'),
(12, 'Mari Cole', 'bubewaseku@mailinator.com', 'Architecto id mollit'),
(13, 'Brenda Stanton', 'qahuf@mailinator.com', 'Fugit velit non ra'),
(14, 'Allen Lindsey', 'hewocyfi@mailinator.com', 'Alias ipsum quo ven'),
(15, 'Ima Lawson', 'kepine@mailinator.com', 'Sed ea aliquam dolor'),
(16, 'Jade Mcconnell', 'komomu@mailinator.com', 'Nihil explicabo Rep'),
(17, 'Teegan Sargent', 'budip@mailinator.com', 'Est aute distinctio'),
(18, 'Imelda Moreno', 'rowunyx@mailinator.com', 'Id architecto quos '),
(19, 'Aristotle Evans', 'xasyfap@mailinator.com', 'Ex tempor reprehende'),
(20, 'Mercedes Browning', 'dykyr@mailinator.com', 'Sed nostrud qui culp');

-- --------------------------------------------------------

--
-- Table structure for table `facts`
--

CREATE TABLE `facts` (
  `id` int NOT NULL,
  `facts_icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `facts_discription` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fact_stasuts` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `facts`
--

INSERT INTO `facts` (`id`, `facts_icon`, `facts_discription`, `fact_stasuts`) VALUES
(1, 'fa fa-arrows-alt', 'Ut omnis fugiat vol', 'active'),
(2, 'fa fa-american-sign-language-interpreting', 'Adipisicing doloremq', 'inactive'),
(4, 'fa fa-film', 'Adipisci est quo lau', 'active'),
(5, 'fa fa-anchor', 'Sit proident tenetu', 'active'),
(6, 'fa fa-diamond', 'Quis quam aperiam au', 'active'),
(7, 'fa fa-fort-awesome', 'Et dolores molestiae', 'active'),
(8, 'fa fa-graduation-cap', 'Sint et neque except', 'active'),
(9, 'fa fa-envelope-open-o', 'Labore sint sed volu', 'active'),
(10, 'fa fa-cc-visa', 'Est vel irure eaque', 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `service_title` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `service_icon` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `service_description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `service_status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_title`, `service_icon`, `service_description`, `service_status`) VALUES
(16, 'Reiciendis est amet', 'fa fa-address-book', 'Ipsam libero cum obc', 'active'),
(17, 'Sint distinctio Con', 'fa fa-arrows', 'Expedita exercitatio', 'active'),
(19, 'Dolore in quam volup', 'fa fa-fighter-jet', 'Maxime eum ut et har', 'active'),
(20, 'Nostrud ipsum quia ', 'fa fa-apple', 'Eu maiores laboris d', 'active'),
(21, 'Deleniti voluptate i', 'fa fa-font', 'Sint reiciendis cupi', 'active'),
(22, 'Aspernatur in minus ', 'fa fa-area-chart', 'Anim ad architecto e', 'inactive'),
(23, 'Web DeveLopment', 'fa fa-cc-mastercard', 'Expedita exercitatio', 'active'),
(25, 'Quam sit quia amet ', 'fa fa-font', 'A lorem ut reprehend', 'active'),
(27, 'Quo et minima elit ', 'fa fa-chain', 'Temporibus odit porr', 'inactive'),
(28, 'Sint quo voluptate ', 'fa fa-apple', 'Adipisicing earum et', 'active'),
(29, 'Et labore autem a ne', 'fa fa-blind', 'Et nemo repudiandae ', 'inactive'),
(30, 'Voluptatem velit odi', 'fa fa-wikipedia-w', 'Nisi quis iusto et m', 'active'),
(32, 'Minus et earum quia ', 'fa fa-deafness', 'Atque aliquid repreh', 'inactive'),
(33, 'Magna quis Nam irure', 'fa fa-diamond', 'Ratione blanditiis i', 'active'),
(34, 'Sequi iure sunt ipsu', 'fa fa-hourglass-start', 'Illo cillum quasi qu', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `description`, `comment`, `image`, `status`) VALUES
(1, 'Zena Mcintosh', 'Chastity Hickman', 'value=&quot;value=&quot;value=&quot;Pariatur Culpa labo&quot;&quot;&quot;', '1_1668494184.jpg', 'active'),
(3, 'Roth Chandler', 'Celeste Key', 'value=&quot;Officia voluptatem&quot;', '30_1668489140.jpg', 'active'),
(4, 'Nolan Mercer', 'Tamara Floyd', 'Sit cumque consequa', '30_1668489149.jpg', 'active'),
(5, 'Darius Gardner', 'Mohammad Lynch', 'value=&quot;Culpa voluptas in m&quot;', '30_1668489157.jpg', 'active'),
(6, 'Renee Johnston', 'Zane Brown', 'value=&quot;Sunt aliqua Adipisc&quot;', '30_1668489169.jpg', 'active'),
(7, 'Maya Lindsay', 'Arsenio Kidd', 'Velit aut provident', '30_1668489179.jpg', 'active'),
(8, 'Malik Welch', 'Danielle Nixon', 'Maxime est dolores n', '30_1668489195.jpg', 'inactive'),
(9, 'Lana Woodard', 'Wynne Pierce', 'Quis eum expedita do', '30_1668491873.jpg', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `works`
--

CREATE TABLE `works` (
  `id` int NOT NULL,
  `work_title` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `work_heading` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `work_description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `work_status` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `work_img` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `works`
--

INSERT INTO `works` (`id`, `work_title`, `work_heading`, `work_description`, `work_status`, `work_img`) VALUES
(11, 'Voluptatem Aut volu', 'Dolor rerum obcaecat', 'Velit qui anim eos', 'active', '_1668070688.jpg'),
(12, 'Provident architect', 'Provident architect', 'Consequatur consequa', 'active', '12_1668234319.jpg'),
(13, 'Modi dolore rerum nu', 'Vitae labore id dol', 'Inventore quia quide', 'active', '_1668070713.png'),
(14, 'Ipsa totam et aut e', 'Quam aperiam ut fuga', 'Magni molestiae sint', 'active', '_1668070725.jpg'),
(15, 'Pariatur Modi verit', 'Pariatur Modi verit', 'Ipsum dolorem ipsum', 'active', '15_1668113285.png'),
(17, 'Est fugiat doloribus', 'Anim dignissimos non', 'Nesciunt esse imped', 'active', '_1668070804.jpg'),
(18, 'Earum voluptatum neq', 'Magna maxime volupta', 'Et dolore qui do con', 'active', '_1668070821.jpg'),
(19, 'Minim eligendi repud', 'Officia aliquid amet', 'Fugit sunt maiores', 'active', '_1668070875.png'),
(20, 'Labore nesciunt tem', 'Laboris sit facilis', 'Ut voluptatem mollit', 'active', '_1668070899.jpg'),
(21, 'Proident sint quo c', 'Ab architecto in cum', 'Anim qui temporibus', 'active', '_1668070915.jpg'),
(22, 'Libero adipisicing n', 'Ullamco accusantium', 'Sed ut aliqua Iusto', 'active', '_1668070942.jpg'),
(23, 'Unde id et voluptat', 'Lorem incididunt rer', 'Eius dicta fugit au', 'active', '_1668070954.jpg'),
(24, 'Do temporibus non qu', 'Accusamus est qui q', 'Inventore doloribus', 'active', '_1668070967.jpg'),
(26, 'Ut quisquam ullamco', 'Ut quisquam ullamco', 'Optio laboris moles', 'active', '_1668235304.jpg'),
(28, 'Sit omnis laborum T', 'Sit omnis laborum T', 'Eum molestiae amet', 'active', '_1668236440.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aouths`
--
ALTER TABLE `aouths`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `facts`
--
ALTER TABLE `facts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `works`
--
ALTER TABLE `works`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `aouths`
--
ALTER TABLE `aouths`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `facts`
--
ALTER TABLE `facts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `works`
--
ALTER TABLE `works`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
